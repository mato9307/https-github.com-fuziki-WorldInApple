cd ${PROJECT_DIR}/Library/Platforms/macOS/Bundle/rs
./rs
