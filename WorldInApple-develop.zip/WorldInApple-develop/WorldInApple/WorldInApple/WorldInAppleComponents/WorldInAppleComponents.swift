//
//  WorldInAppleComponents.swift
//  WorldInApple
//
//  Created by fuziki on 2020/02/09.
//  Copyright © 2020 factory.fuziki. All rights reserved.
//

import Foundation

protocol WorldInAppleComponents {
    init(parameters: WorldInAppleParameters)
}
